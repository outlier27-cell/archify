/** Serialize computed layout for dry-run / inspect (#9). */

export function componentBox(c) {
  return {
    id: c.id,
    type: c.type,
    label: c.label,
    x: Math.round(c.x),
    y: Math.round(c.y),
    width: c.width,
    height: c.height,
    ...(Number.isInteger(c.row) ? { row: c.row } : {}),
    ...(Number.isInteger(c.col) ? { col: c.col } : {}),
    ...(Array.isArray(c.pos) ? { pos: c.pos.map(Math.round) } : {}),
  };
}

export function entityBox(e) {
  return {
    id: e.id,
    label: e.label,
    x: Math.round(e.x),
    y: Math.round(e.y),
    width: e.width,
    height: e.height,
    attributes: (Array.isArray(e.attributes) ? e.attributes : []).map((attribute) => attribute.name),
    ...(Number.isInteger(e.row) ? { row: e.row } : {}),
    ...(Number.isInteger(e.col) ? { col: e.col } : {}),
    ...(Array.isArray(e.pos) ? { pos: e.pos.map(Math.round) } : {}),
  };
}

export function boundaryBox(b) {
  return {
    kind: b.kind,
    label: b.label,
    x: Math.round(b.x),
    y: Math.round(b.y),
    width: Math.round(b.width),
    height: Math.round(b.height),
    wraps: b.wraps,
  };
}

export function connectionPath(conn, routed, labelAt) {
  return {
    from: conn.from,
    to: conn.to,
    label: conn.label ?? null,
    variant: conn.variant ?? 'default',
    route: conn.route ?? 'auto',
    // These points are repair inputs: rounding a fractional port makes a
    // reused waypoint diagonal relative to the actual endpoint.
    points: routed.points.map(([x, y]) => [x, y]),
    ...(labelAt ? { labelAt: labelAt.map(Math.round) } : {}),
  };
}
