"""Python import extractor for Bauify.

Reads a JSON document on stdin: {"files": ["rel/path.py", ...], "sources": {"rel/path.py": "<base64 bytes>"}}
Writes a JSON document on stdout:
  {"files": [{"path", "loc", "imports": [...], "symbols": [...], "error"?}], "python": "3.x.y"}
Each symbol is a module-scope binding: {"name", "kind": "function"|"class"|"variable"|"import", "line"}
  (the line where the name becomes bound; what a `from m import name` elsewhere
  needs to have executed already when `m` is only partially initialised).
Each function: {"name", "qualname", "line", "endLine", "complexity", "nesting", "deepestLine"}
  (see `functions` for how complexity and nesting are counted).
Each import: {"line", "kind": "static"|"dynamic", "level", "module", "names"}
  - `import a.b as c`       -> level 0, module "a.b",  names ["*"]
  - `from a.b import x, y`  -> level 0, module "a.b",  names ["x", "y"]
  - `from . import x`       -> level 1, module "",     names ["x"]
  - `from ..p import *`     -> level 2, module "p",    names ["*"]
  - importlib.import_module("a.b") / __import__("a.b") with a literal -> kind "dynamic"
Resolution against the file set happens in Node so both adapters share one policy.
Standard library only; no third-party imports.
"""
import ast
import base64
import io
import json
import platform
import sys
import tokenize
from ast_walk import AnalysisVisitor, analysis_children
from loader_bindings import standard_loader_calls
from calls import collect_calls, source_range, source_lines


def line_count(text):
    if not text:
        return 0
    lines = text.splitlines()
    return len(lines)


def literal_module(node):
    if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
        return node.args[0].value
    return None


def collect(tree):
    """Keep lexical scope separate from execution guarantees.

    A function body is deferred, but its defaults/decorators are evaluated in
    the enclosing scope. A deferred function may itself be called during
    module initialization; `lazy` is deliberately not a proof of safety.
    """
    # Recognize typing aliases only when they have one unambiguous binding.
    # Reassignment or shadowing anywhere makes this conservative: retain the
    # possible runtime edge instead of incorrectly erasing it as type-only.
    loader_calls = standard_loader_calls(tree)
    bindings = {}
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            names = [node.id]
        elif isinstance(node, ast.Attribute) and isinstance(node.ctx, (ast.Store, ast.Del)) and isinstance(node.value, ast.Name):
            names = [node.value.id]
        elif isinstance(node, ast.ExceptHandler) and node.name:
            names = [node.name]
        elif isinstance(node, ast.arg):
            names = [node.arg]
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names = [node.name]
        elif isinstance(node, ast.Import):
            names = [a.asname or a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            names = [a.asname or a.name for a in node.names]
        for name in names:
            bindings[name] = bindings.get(name, 0) + 1
    typing_names, type_checks = {}, {}
    for node in tree.body:
        if isinstance(node, ast.Import):
            for a in node.names:
                name = a.asname or a.name
                if a.name == "typing" and bindings.get(name) == 1:
                    typing_names[name] = node.lineno
        elif isinstance(node, ast.ImportFrom) and node.module == "typing" and not node.level:
            for a in node.names:
                name = a.asname or a.name
                if a.name == "TYPE_CHECKING" and bindings.get(name) == 1:
                    type_checks[name] = node.lineno

    class Collector(AnalysisVisitor):
        def __init__(self):
            self.found = []
            self.flags = {}

        def under(self, flags, nodes):
            previous = self.flags
            self.flags = {**previous, **flags}
            for node in nodes:
                self.visit(node)
            self.flags = previous

        def emit(self, node, **fields):
            self.found.append({"line": node.lineno, "column": node.col_offset, **fields, **self.flags})

        def visit_FunctionDef(self, node):
            self.under({"lazy": True}, getattr(node, "type_params", []))
            # Only the body is lazy, not default expressions or decorators.
            for expr in node.decorator_list + node.args.defaults + [d for d in node.args.kw_defaults if d]:
                self.visit(expr)
            # Annotation evaluation varies with future annotations and Python
            # versions. Keep imports in them as conditional evidence.
            args = node.args.posonlyargs + node.args.args + node.args.kwonlyargs
            args += [a for a in (node.args.vararg, node.args.kwarg) if a]
            annotations = [a.annotation for a in args if a.annotation]
            if node.returns:
                annotations.append(node.returns)
            self.under({"conditional": True}, annotations)
            self.under({"lazy": True}, node.body)

        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_ClassDef(self, node):
            # Bounds are lazy; bases, decorators and the class body retain outer scope.
            self.under({"lazy": True}, getattr(node, "type_params", []))
            for expr in node.decorator_list + node.bases + node.keywords + node.body:
                self.visit(expr)

        def visit_TypeAlias(self, node):
            # PEP 695 alias values and parameter bounds evaluate on demand.
            self.under({"lazy": True}, getattr(node, "type_params", []) + [node.value])

        def visit_Lambda(self, node):
            for expr in node.args.defaults + [d for d in node.args.kw_defaults if d]:
                self.visit(expr)
            self.under({"lazy": True}, [node.body])

        def visit_If(self, node):
            test = node.test
            negated = isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not)
            check = test.operand if negated else test
            is_type_check = (
                isinstance(check, ast.Name) and type_checks.get(check.id, float("inf")) < node.lineno
            ) or (
                isinstance(check, ast.Attribute) and check.attr == "TYPE_CHECKING"
                and isinstance(check.value, ast.Name)
                and typing_names.get(check.value.id, float("inf")) < node.lineno
            )
            self.visit(test)
            if is_type_check:
                self.under({"typeOnly": True}, node.orelse if negated else node.body)
                self.under({}, node.body if negated else node.orelse)
            else:
                self.under({"conditional": True}, node.body + node.orelse)

        def visit_Match(self, node):
            self.visit(node.subject)
            self.under({"conditional": True}, node.cases)

        def visit_Try(self, node):
            self.under({"conditional": True}, node.body + node.handlers + node.orelse)
            self.under({}, node.finalbody)

        visit_TryStar = visit_Try

        def visit_For(self, node):
            self.visit(node.iter)
            self.under({"conditional": True}, [node.target] + node.body + node.orelse)

        visit_AsyncFor = visit_For

        def visit_While(self, node):
            self.visit(node.test)
            self.under({"conditional": True}, node.body + node.orelse)

        def visit_IfExp(self, node):
            self.visit(node.test)
            self.under({"conditional": True}, [node.body, node.orelse])

        def visit_BoolOp(self, node):
            self.visit(node.values[0])
            self.under({"conditional": True}, node.values[1:])

        def comprehension(self, node, values, lazy=False):
            # Python evaluates the outer iterable when constructing even a
            # generator. Everything after it depends on iteration and filters.
            self.visit(node.generators[0].iter)
            body = []
            for index, generator in enumerate(node.generators):
                if index:
                    body.append(generator.iter)
                body.extend([generator.target, *generator.ifs])
            self.under({"conditional": True, **({"lazy": True} if lazy else {})}, body + values)

        def visit_GeneratorExp(self, node):
            self.comprehension(node, [node.elt], lazy=True)

        def visit_ListComp(self, node):
            self.comprehension(node, [node.elt])

        visit_SetComp = visit_ListComp

        def visit_DictComp(self, node):
            self.comprehension(node, [node.key, node.value])

        def visit_Import(self, node):
            for alias in node.names:
                self.emit(node, kind="static", level=0, module=alias.name, names=["*"])

        def visit_ImportFrom(self, node):
            self.emit(node, kind="static", level=node.level or 0, module=node.module or "",
                      names=sorted(alias.name for alias in node.names))

        def visit_Call(self, node):
            if id(node) in loader_calls:
                target = literal_module(node)
                self.emit(node, kind="dynamic", level=0, module=target or "<computed>",
                          names=[], **({"opaque": True} if target is None else {}))
            self.generic_visit(node)

    collector = Collector()
    collector.visit(tree)
    return sorted(collector.found, key=lambda i: (i["line"], i["module"]))


def module_bindings(tree):
    """Module-scope names in the order they are bound. Walks into if/try/with
    blocks at module level (still executed at import time) but not into
    function or class bodies. Later re-bindings keep the first line: the name
    exists from then on."""
    seen = {}
    def bind(name, kind, line):
        if name not in seen:
            seen[name] = {"name": name, "kind": kind, "line": line}
    def targets(node):
        if isinstance(node, ast.Name):
            return [node.id]
        if isinstance(node, (ast.Tuple, ast.List)):
            return [n for elt in node.elts for n in targets(elt)]
        return []
    def walk(body):
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                bind(node.name, "function", node.lineno)
            elif isinstance(node, ast.ClassDef):
                bind(node.name, "class", node.lineno)
            elif isinstance(node, ast.Assign):
                for t in node.targets:
                    for name in targets(t):
                        bind(name, "variable", node.lineno)
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)) and node.value is not None:
                for name in targets(node.target):
                    bind(name, "variable", node.lineno)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    bind(alias.asname or alias.name.split(".")[0], "import", node.lineno)
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if alias.name != "*":
                        bind(alias.asname or alias.name, "import", node.lineno)
            elif isinstance(node, (ast.If, ast.Try, ast.With, ast.For, ast.While)):
                for attr in ("body", "orelse", "finalbody", "handlers"):
                    for child in getattr(node, attr, []) or []:
                        if isinstance(child, ast.ExceptHandler):
                            walk(child.body)
                        else:
                            walk([child])
    walk(tree.body)
    return sorted(seen.values(), key=lambda b: (b["line"], b["name"]))


# Function-level measurements. Cyclomatic complexity follows the usual
# McCabe/radon reading: 1 for the function, +1 for each if/elif, loop, except
# handler, conditional expression, match case (an irrefutable `case _` adds
# nothing), comprehension `for` and `if`, and each extra operand of `and`/`or`.
# Nesting is the deepest stack of blocks (if/for/while/with/try/match) inside
# the body; `elif` stays at its `if`'s depth. Nested functions and classes are
# measured on their own and are not added to their parent; lambdas are part of
# the function that contains them.
_MATCH = getattr(ast, "Match", None)
_TRY_STAR = getattr(ast, "TryStar", None)
_BLOCKS = tuple(t for t in (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.Try, _TRY_STAR, _MATCH) if t is not None)
_LOOPS = (ast.For, ast.AsyncFor, ast.While)
_SCOPES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def _is_irrefutable(case):
    pattern = case.pattern
    return case.guard is None and isinstance(pattern, getattr(ast, "MatchAs", ())) and pattern.pattern is None


def _measure(func):
    state = {"complexity": 1, "nesting": 0, "deepest": func.lineno}

    def visit(node, depth):
        for child in analysis_children(node):
            if isinstance(child, _SCOPES):
                continue  # measured separately
            child_depth = depth
            if isinstance(child, ast.If):
                state["complexity"] += 1
            elif isinstance(child, _LOOPS):
                state["complexity"] += 1
            elif isinstance(child, ast.ExceptHandler):
                state["complexity"] += 1
            elif isinstance(child, ast.IfExp):
                state["complexity"] += 1
            elif isinstance(child, ast.BoolOp):
                state["complexity"] += len(child.values) - 1
            elif isinstance(child, ast.comprehension):
                state["complexity"] += 1 + len(child.ifs)
            elif _MATCH is not None and isinstance(child, ast.match_case):
                if not _is_irrefutable(child):
                    state["complexity"] += 1
            if isinstance(child, _BLOCKS):
                # `elif` is an If alone in its parent If's orelse: same depth.
                is_elif = isinstance(child, ast.If) and isinstance(node, ast.If) and node.orelse == [child]
                child_depth = depth if is_elif else depth + 1
                if child_depth > state["nesting"]:
                    state["nesting"] = child_depth
                    state["deepest"] = child.lineno
            visit(child, child_depth)

    visit(func, 0)
    return state


def functions(tree, text):
    out = []
    # Token columns are Unicode character offsets; AST columns are UTF-8 bytes.
    # In particular, a parenthesized decorator's AST starts after its opening
    # parentheses, potentially on another line. Find the owning @ token instead.
    decorator_tokens = []
    for token in tokenize.generate_tokens(io.StringIO(text.replace('\r\n', '\n').replace('\r', '\n')).readline):
        if token.type == tokenize.OP and token.string == '@' and not token.line[:token.start[1]].strip():
            decorator_tokens.append(token)

    def definition(node):
        start = node
        if node.decorator_list:
            first = node.decorator_list[0]
            lines, _ = source_lines(text)
            candidates = [token for token in decorator_tokens
                          if len(lines[token.start[0] - 1][:token.start[1]].encode('utf-8')) == node.col_offset
                          and (token.start[0], len(lines[token.start[0] - 1][:token.start[1]].encode('utf-8'))) <= (first.lineno, first.col_offset)]
            token = candidates[-1]
            start = ast.Constant(value=None)
            start.lineno, column = token.start
            start.col_offset = len(lines[start.lineno - 1][:column].encode('utf-8'))
            start.end_lineno, start.end_col_offset = node.end_lineno, node.end_col_offset
        return {"kind": type(node).__name__, "sourceRange": source_range(start, text)}

    def walk(node, prefix):
        for child in analysis_children(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                qualname = prefix + child.name
                m = _measure(child)
                out.append({
                    "name": child.name, "qualname": qualname, "line": child.lineno,
                    "endLine": getattr(child, "end_lineno", None) or child.lineno,
                    "sourceRange": source_range(child, text),
                    "definition": definition(child),
                    "complexity": m["complexity"], "nesting": m["nesting"], "deepestLine": m["deepest"],
                })
                walk(child, qualname + ".<locals>.")
            elif isinstance(child, ast.ClassDef):
                walk(child, prefix + child.name + ".")
            elif not isinstance(child, ast.Lambda):
                walk(child, prefix)

    walk(tree, "")
    return sorted(out, key=lambda f: (f["line"], f["qualname"]))


def main():
    request = json.load(sys.stdin)
    out = []
    for rel in request["files"]:
        raw = base64.b64decode(request["sources"][rel], validate=True)
        record = {"path": rel, "loc": 0, "imports": [], "symbols": [], "functions": [], "sourceText": ""}
        try:
            encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
            text = raw.decode(encoding)
            record.update(loc=line_count(text), sourceText=text)
            tree = ast.parse(text, filename=rel)
            record["imports"] = collect(tree)
            record["symbols"] = module_bindings(tree)
            record["functions"] = functions(tree, text)
            record["calls"], record["definitions"], record["importBindings"] = collect_calls(tree, text)
        except (SyntaxError, ValueError, UnicodeError, LookupError) as error:
            record["error"] = "%s (line %s)" % (getattr(error, "msg", str(error)), getattr(error, "lineno", None))
        out.append(record)
    json.dump({"files": out, "python": platform.python_version()}, sys.stdout)


if __name__ == "__main__":
    main()
